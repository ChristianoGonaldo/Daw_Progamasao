package jcolonia.daw2023.menuIdeal;

import java.time.LocalDate;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;

/**
 * Clase para añadir la comida del array de comida con ingredientes a una dieta que tiene sus atributos de dia de la semana
 * No se añade por falta de tiempo
 */
public class Dieta {

	/**
	 * Variable usada en el construcot para saber si es el tipo de comida con ingredientes o semanal
	 */
	/**
	 * El nombre del plato
	 */
	private String diaDeLaSemana;
	/**
	 * fecha en la que se añadio el plato
	 */
	private LocalDate fechaPreparacion;

	/**
	 * Variable para que el usuario ingrese lo que le toca
	 */
	private String desayuno = "No toca";
	
	/**
	 * Variable para que el usuario ingrese lo que le toca
	 */
	private String almuerzo = "No toca";;
	
	/**
	 * Variable para que el usuario ingrese lo que le toca
	 */
	private String comida = "No toca";;
	
	/**
	 * Variable para que el usuario ingrese lo que le toca
	 */
	private String merienda = "No toca";;
	
	/**	 
	 * Variable para que el usuario ingrese lo que le toca
	 */
	private String cena = "No toca";;

	/**
	 * Variable para hacer el toString
	 */
	private String textamento = "DEFAULT";

	/**
	 * Constructor para agregar comida semanal
	 * @param diaDeLaSemana variable para ingresar el nombre de la comida
	 * @param desayuno variable para ingresar el nombre de la comida
	 * @param almuerzo variable para ingresar el nombre de la comida
	 * @param comida variable para ingresar el nombre de la comida
	 * @param merienda variable para ingresar el nombre de la comida
	 * @param cena variable para ingresar el nombre de la comida
	 */
	public Dieta(String diaDeLaSemana, String desayuno, String almuerzo, String comida, String merienda, String cena) {
		this.diaDeLaSemana = diaDeLaSemana;
		this.desayuno = desayuno;
		this.almuerzo = almuerzo;
		this.comida = comida;
		this.merienda = merienda;
		this.cena = cena;
		if (diaDeLaSemana != null && desayuno != null && almuerzo != null && comida != null && merienda != null
				&& cena != null) {
			this.textamento = String.format(VistaGeneral.YELLOW  + VistaGeneral.BG_BLUE
					+ "<<" + diaDeLaSemana + ">>:" + VistaGeneral.RESET + VistaGeneral.CYAN
					+ "\nDesayuno -> " + VistaGeneral.GREEN  + desayuno + VistaGeneral.CYAN
					+ "\nAlmuerzo -> " + VistaGeneral.GREEN + almuerzo + VistaGeneral.CYAN
					+ "\nComida ---> " + VistaGeneral.GREEN + comida + VistaGeneral.CYAN
					+ "\nMerienda -> " + VistaGeneral.GREEN + merienda + VistaGeneral.CYAN
					+ "\nCena  ----> " + VistaGeneral.GREEN + cena + VistaGeneral.RESET + "\n");
		} else {
			this.textamento = String.format(VistaGeneral.RED + "NULL" + VistaGeneral.RESET);
		}
	}

	/**
	 * @return el nombre del platillo
	 */
	public String getNombrePlatillo() {
		return diaDeLaSemana;
	}

	/**
	 * @param nombre variable para establecer el nombre del dia
	 */
	public void setNombrePlatillo(String nombre) {
		this.diaDeLaSemana = nombre;
	}

	
	/**
	 * Método para crear una lista de Strin para coger los ingredientes
	 * @return una copia para mantener la encapsulación
	 */


	public String getDiaDeLaSemana() {
		return diaDeLaSemana;
	}

	/**
	 * @param diaDeLaSemana para cambiar el atributo del dia de la semana
	 */
	public void setDiaDeLaSemana(String diaDeLaSemana) {
		this.diaDeLaSemana = diaDeLaSemana;
	}

	
	/**
	 * @return el desayuno
	 */
	public String getDesayuno() {
		return desayuno;
	}

	/**
	 * @param desayuno para cambiar el atributo del desayuno
	 */
	public void setDesayuno(String desayuno) {
		this.desayuno = desayuno;
	}

	/**
	 * @return el aluerzo
	 */
	public String getAlmuerzo() {
		return almuerzo;
	}

	/**
	 * @param almuerzo para cambiar el atributo del almuerzo
	 */
	public void setAlmuerzo(String almuerzo) {
		this.almuerzo = almuerzo;
	}

	/**
	 * @return la comida
	 */
	public String getComida() {
		return comida;
	}

	/**
	 * @param comida cambiar el valor de la comida
	 */
	public void setComida(String comida) {
		this.comida = comida;
	}

	/**
	 * @return conseguir la merienda
	 */
	public String getMerienda() {
		return merienda;
	}

	/**
	 * @param merienda cambiar el valor de la merienda
	 */
	public void setMerienda(String merienda) {
		this.merienda = merienda;
	}

	/**
	 * @return conseguir la cena
	 */
	public String getCena() {
		return cena;
	}

	/**
	 * @param cena cambiar la cena
	 */
	public void setCena(String cena) {
		this.cena = cena;
	}

	/**
	 * @return conseguir el texto que se imprime por pantalla
	 */
	public String getTextamento() {
		return textamento;
	}

	/**
	 * @param textamento cambiar el valor del textamento
	 */
	public void setTextamento(String textamento) {
		this.textamento = textamento;
	}

	/**
	 * Método para conseguir la fechaPreparacón
	 * @return la fechaPreparación
	 */
	public LocalDate getFechaPreparacion() {
		return fechaPreparacion;
	}

	/**
	 * Método para establecer la fechaPreparación
	 * @param fechaPreparacion para igualar al atributo de la clase
	 */
	public void setFechaPreparacion(LocalDate fechaPreparacion) {
		this.fechaPreparacion = fechaPreparacion;
	}

	@SuppressWarnings("javadoc")
	public String toString() {
		return textamento;
	}

	/**
	 * Método para convetir comida, a un String que se pueda escribir en un archivo
	 * de forma cómoda El switch es para que depende del constructor usado para
	 * crear el objeto se use un método u otro.
	 * @param bonito Variable para saber si exportar bonito o no
	 * @return el String con todo el texto listo para exportar
	 */
	public String convertidorAString(boolean bonito) {
		StringBuilder stringBuilder = new StringBuilder();
		if(bonito) {
			stringBuilder = convertirAStringSemanalBonito(stringBuilder);
		}else {				
			stringBuilder = convertirAStringSemanal(stringBuilder);
		}
		return stringBuilder.toString();
	}
	
	/**
	 * Método para transformar el objeto a texto plano, de forma que luego se puede usar para importar
	 * @param stringBuilder variable con los datos guardados
	 * @return duelve la variable
	 * string = String.format("%d%s%s%s%s%s%s", switcher, nombre, desayuno, almuerzo, comida, merienda, cena); //Posible intento
	 */
	public StringBuilder convertirAStringSemanal(StringBuilder stringBuilder) {
		stringBuilder.append(diaDeLaSemana).append(";").append(desayuno).append(";").append(almuerzo)
				.append(";").append(comida).append(";").append(merienda).append(";").append(cena);
		return stringBuilder;
	}
	
	/**
	 * Método para transformar el objeto a texto plano, de forma que luego NO se puede usar para importar
	 * Se esta mirando este método para comprobar se es capaz de hacer que un stringBuilder haga una tabla
	 * @param stringBuilder Meter el formato de texto
	 * @return el stringBuilder en forma de tabla
	 */
	public StringBuilder convertirAStringSemanalBonito(StringBuilder stringBuilder) {
	    int maxAncho;
	    
	    maxAncho = Math.max(diaDeLaSemana.length(), desayuno.length());
	    maxAncho = Math.max(maxAncho, almuerzo.length());
	    maxAncho = Math.max(maxAncho, comida.length());
	    maxAncho = Math.max(maxAncho, merienda.length());
	    maxAncho = Math.max(maxAncho, cena.length());
	    maxAncho = Math.max(maxAncho, "Dieta".length());
	    
	    maxAncho = maxAncho + 20;

	    stringBuilder.append("+").append(String.format("%-" + (maxAncho +1) + "s", "").replace(' ', '-')).append("+\n");
	    stringBuilder.append("|").append(String.format("%-" + maxAncho + "s", diaDeLaSemana)).append(" |\n");
	    stringBuilder.append("+").append(String.format("%-" + (maxAncho+1) + "s", "").replace(' ', '-')).append("+\n");

//	     stringBuilder.append("|").append(String.format("%-" + maxAncho + "s", "Día: " + nombre)).append(" |\n")
	    stringBuilder.append("|").append(String.format("%-" + maxAncho + "s", "Desayuno: " + desayuno)).append(" |\n")
	                  .append("|").append(String.format("%-" + maxAncho + "s", "Almuerzo: " + almuerzo)).append(" |\n")
	                  .append("|").append(String.format("%-" + maxAncho + "s", "Comida: " + comida)).append(" |\n")
	                  .append("|").append(String.format("%-" + maxAncho + "s", "Merienda: " + merienda)).append(" |\n")
	                  .append("|").append(String.format("%-" + maxAncho + "s", "Cena: " + cena)).append(" |\n");

	    stringBuilder.append("+").append(String.format("%-" + (maxAncho+1) + "s", "").replace(' ', '-')).append("+\n");

	    return stringBuilder;
	}

	/**
	 * Método para convertir a objeto los datos sacados de un array
	 * Es el método para importar la comida semanal, tener cuidado, porque solo funciona si se ha exportado de forma correcta
	 * @param datosComida variable donde se guardan los datos
	 * @return el objeto creado
	 */
	public static Comida toComidaSemanal(String[] datosComida) {
		String nombrePlatillo = datosComida[1];
		String desayuno = datosComida[2];
		String almuerzo = datosComida[3];
		String comida = datosComida[4];
		String merienda = datosComida[5];
		String cena = datosComida[6];

		return new Comida(nombrePlatillo, desayuno, almuerzo, comida, merienda, cena);
	}

}
